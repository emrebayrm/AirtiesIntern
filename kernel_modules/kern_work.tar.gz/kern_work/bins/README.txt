== initialization ==
cp userapp /home/stajer/teeny-linux/initramfs/x86-busybox/project

cp hello_world.ko /home/stajer/teeny-linux/initramfs/x86-busybox/lib/modules

cp run.sh /home/stajer/teeny-linux

== build ==
/home/stajer/teeny-linux
./run.sh

== run ==
qemu-system-x86_64 \
    -kernel obj/linux-x86-basic/arch/x86_64/boot/bzImage \
    -initrd obj/initramfs-busybox-x86.cpio.gz \
    -nographic -append "console=ttyS

# in qemu insmod module
insmod /lib/modules/hello_world.ko

# see it's major number
cat /proc/devices

# insmo
major=248
dev="hello-dev"

mknod "/dev/$dev" c "$major" 0

# initialize dev-null
mount - remount
mknod /dev/null c 1 3

# run userspace app
./userapp /dev/hello-dev poll
echo "abc" > /proc/hello_proc
